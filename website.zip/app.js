const wrapper = document.querySelector(".sliderWrapper")

console.log(wrapper)

wrapper.Style.transform = "translateX(1000px)"