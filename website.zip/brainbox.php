<?php
session_start();
error_reporting(0);
include('<asset/adminArea/connect.php');
include('includes/top-header.php');
if(isset($_GET['action']) && $_GET['action']=="add"){
	$id=intval($_GET['id']);
	if(isset($_SESSION['cart'][$id])){
		$_SESSION['cart'][$id]['quantity']++;
	}else{
		$sql_p="SELECT * FROM products WHERE id={$id}";
		$query_p=mysqli_query($con,$sql_p);
		if(mysqli_num_rows($query_p)!=0){
			$row_p=mysqli_fetch_array($query_p);
			$_SESSION['cart'][$row_p['id']]=array("quantity" => 1, "price" => $row_p['productPrice']);
			header('location:index.php');
		}else{
			$message="Product ID is invalid";
		}
	
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./asset/css/brainbox.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@200;300;400;500;600;700;800&family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.2.1/css/fontawesome.min.css">
    <title>ANIMOIJINLE</title>
</head>
<body>
    <?php 
            include('includes/nav.php');
            include('includes/menubar.php');
            ?>
    
   

    <div class="pageTitle">
        <h3>Brainbox</h3>
        <P>Meet the intellectuals behind AESTYL!</P>
    </div>

    <div class="brainbox">
        <div class="row1">
            <img src="./asset/image/AESTYL_LOGO-removebg-preview (1).png" alt="">
            <h3>NAME NAME</h3>
            <h4>PORTFOLIO</h4>
            <H4>"QOUTE"</H4>
        </div>

        <div class="row1">
            <img src="./asset/image/AESTYL_LOGO-removebg-preview (1).png" alt="">
            <h3>NAME NAME</h3>
            <h4>PORTFOLIO</h4>
            <H4>"QOUTE"</H4>
        </div>

        <div class="row1">
            <img src="./asset/image/AESTYL_LOGO-removebg-preview (1).png" alt="">
            <h3>NAME NAME</h3>
            <h4>PORTFOLIO</h4>
            <H4>"QOUTE"</H4>
        </div>

        <div class="row1">
            <img src="./asset/image/AESTYL_LOGO-removebg-preview (1).png" alt="">
            <h3>NAME NAME</h3>
            <h4>PORTFOLIO</h4>
            <H4>"QOUTE"</H4>
        </div>

        <div class="row1">
            <img src="./asset/image/AESTYL_LOGO-removebg-preview (1).png" alt="">
            <h3>NAME NAME</h3>
            <h4>PORTFOLIO</h4>
            <H4>"QOUTE"</H4>
        </div>

        <div class="row1">
            <img src="./asset/image/AESTYL_LOGO-removebg-preview (1).png" alt="">
            <h3>NAME NAME</h3>
            <h4>PORTFOLIO</h4>
            <H4>"QOUTE"</H4>
        </div>

        <div class="row1">
            <img src="./asset/image/AESTYL_LOGO-removebg-preview (1).png" alt="">
            <h3>NAME NAME</h3>
            <h4>PORTFOLIO</h4>
            <H4>"QOUTE"</H4>
        </div>

        <div class="row1">
            <img src="./asset/image/AESTYL_LOGO-removebg-preview (1).png" alt="">
            <h3>NAME NAME</h3>
            <h4>PORTFOLIO</h4>
            <H4>"QOUTE"</H4>
        </div>

        <div class="row1">
            <img src="./asset/image/AESTYL_LOGO-removebg-preview (1).png" alt="">
            <h3>NAME NAME</h3>
            <h4>PORTFOLIO</h4>
            <H4>"QOUTE"</H4>
        </div>
    </div>

    
   
    
  

   <!---bottomMenu section-->
   <div class="categories">
       <div class="smallcontainer">
           <div class="row">
            <div class="col-5a" >
                <a href="index.html" class="bottomMenu">
                    <img src="./asset/image/AESTYL_LOGO-removebg-preview (1).png" alt="">
                    <h3>Home</h3>
                </a>
                
            </div>
                <div class="col-5a">
                    <a href="forschool.html" class="bottomMenu">
                        <img src="./asset/image/for schools.png" alt="">
                        <h3>Buy for Schools</h3>
                    </a>
                    
                </div>
                <div class="col-5a">
                    <a href="brainbox.html" class="bottomMenu">
                       <img src="./asset/image/brainbox.png" alt="">
                       <h3>Brainbox</h3> 
                    </a>
                    
                </div>
                <div class="col-5a">
                    <a href="scholars.html" class="bottomMenu">
                        <img src="./asset/image/scholars.png" alt="">
                        <h3>Scholars</h3>
                    </a>
                    
                </div>
                <div class="col-5a">
                    <a href="sciencefic.html" class="bottomMenu">
                        <img src="./asset/image/science.png" alt="">
                        <h3>Short Science Fiction</h3>
                    </a>
                    
                </div>
                <div class="col-5a">    
                    <a href="shortstory.html" class="bottomMenu">
                        <img src="./asset/image/short stories.png" alt="">
                        <h3>Short Story Books</h3>
                    </a>
                </div>
                <div class="col-5a">
                    <a href="textbook.html" class="bottomMenu">
                        <img src="./asset/image/textook.png" alt="">
                        <h3>Textbooks</h3>
                    </a>
                    
                </div>
                <div class="col-5a">
                    <a href="competition.html" class="bottomMenu">
                        <img src="./asset/image/competition.png" alt="">
                        <h3>Yoruba Competition</h3>
                    </a>
                    
                </div>
           </div>
       </div>
   </div>

   <!---footer-->
   <div class="backtotop">
    <a href=""><h4>Back to Top ˄</h4></a>
   </div>
   <div class="footer">
       <div class="container">
            <div class="row">
                <div class="footer-col1">
                    <h3>About Us</h3>
                    <p>Lorem ipsum dolor sit amet consectetur<br>Lorem ipsum dolor sit amet consectetur <br>adipisicing elit.</p>
                </div>
                <div class="footer-col2">
                    <h3>Our Goal</h3>
                    <p>Lorem ipsum dolor sit amet consectetur<br>Lorem ipsum dolor sit amet consectetur <br>adipisicing elit.</p>
                </div>
                <div class="footer-col3">
                    <h3>Useful Links</h3>
                    <ul>
                        <li><a href="competition.html">Yoruba Competition</a></li>
                        <li><a href="#">Raffle Draw</a></li>
                        <li><a href="textbook.html">Textbooks</a></li>
                        <li><a href="shortstory.html">Short Stories</a></li>
                        <li><a href="forschool.html">Buy for Schools</a></li>
                    </ul>
                </div>
                <div class="footer-col4">
                    <h3>My Accunt</h3>
                    <ul>
                        <li>My Account</li>
                        <li>Recently Purchased</li>
                        <li>Cart</li>
                        <li>Sign in</li>
                        <li>sign out</li>
                    </ul>
                </div> 
                
            </div>
       </div>
   </div>
   <div class="copywright">
    <h4>© All wright reserved to animoijinle.com</h4>
</div>

<script>
    var menuItems = document.getElementById("menuItems");

    menuItems.style.maxHeight = "0px";

    function menutoggle(){
        if( menuItems.style.maxHeight == "0px")
           {
            menuItems.style.maxHeight = "200px";
           }
           else{
            menuItems.style.maxHeight = "0px";
           }
    }
</script>
</body>
</html>