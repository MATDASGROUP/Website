<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./asset/css/style.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@200;300;400;500;600;700;800&family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.2.1/css/fontawesome.min.css">
    <title>ANIMOIJINLE</title>
</head>
<body>
    <div class="header">
      <div class="container">
        <div class="navbar">
            <div class="logo">
                <img src="./asset/image/Navtop.JPG" width="200px" alt="" id="logo">
            </div>
            <div class="site-title">
                <h1>Animo Ijinle</h1>
            </div><br>
           <!-- <nav>
                <ul id="menuItems">
                    <li><a href="index.php">Home</a></li>
                    <li><a href="forschool.html">Buy For School</a></li>
                    <li><a href="brainbox.html">Brainbox</a></li>
                    <li><a href="scholars.html">Scholars</a></li>
                    <li><a href="sciencefic.html">Sci-Fi Short Story</a></li>
                    <li><a href="textbook.html">Textbooks</a></li>
                    <li><a href="competition.html">Competition</a></li>
                    <li><a href="faq.html">Faqs</a></li>
                </ul>
             </nav>
            <img src="./asset/image/cart.png" width="30px" height="30px"><sup>0</sup>
            <img src="./asset/image/menu-removebg-preview.png" class="menu-icon" onclick="menutoggle()">-->
        </div>
      </div>
  </div>

<script>
    var menuItems = document.getElementById("menuItems");

    menuItems.style.maxHeight = "0px";

    function menutoggle(){
        if( menuItems.style.maxHeight == "0px")
           {
            menuItems.style.maxHeight = "200px";
           }
           else{
            menuItems.style.maxHeight = "0px";
           }
    }
</script>
</body>
</html>