<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="./asset/css/style.css">
  <title>Document</title>
</head>
<body>
<?php 
//session_start();


?>


<div class="cnt-account1">
  <ul class="list-unstyled1">

    <?php if(strlen($_SESSION['login']))
      {   ?>
      <li><a href="#"><i class="icon fa fa-user"></i>Welcome -<?php echo htmlentities($_SESSION['username']);?></a></li>
      <?php } ?>

        <li><a href="my-account.php"><i class="icon fa fa-user"></i>My Account</a></li>
        <li><a href="my-wishlist.php"><i class="icon fa fa-heart"></i>Wishlist</a></li>
        <li><a href="my-cart.php"><i class="icon fa fa-shopping-cart"></i>My Cart</a></li>
        <li><a href="#"><i class="icon fa fa-key"></i>Checkout</a></li>
        <?php if(strlen($_SESSION['login'])==0)
        {   ?>
      <li><a href="login.php"><i class="icon fa fa-sign-in"></i>Login</a></li>
      <?php }
      else{ ?>
	
				<li><a href="logout.php"><i class="icon fa fa-sign-out"></i>Logout</a></li>
				<?php } ?>
        <li class="dropdown dropdown-small">
                <a href="track-orders.php" class="dropdown-toggle" ><span class="key">Track Order</b></a>
                
              </li>	
				</ul>
			</div><!-- /.cnt-account -->

         <!--<div class="cnt-block">
            <ul class="list-unstyled list-inline">
              <li class="dropdown dropdown-small">
                <a href="track-orders.php" class="dropdown-toggle" ><span class="key">Track Order</b></a>
                
              </li>

            
            </ul>
          </div>-->
          
          <div class="clearfix"></div>
        </div><!-- /.header-top-inner -->
	</div><!-- /.container -->
</div><!-- /.header-top -->


</body>
</html>
