<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Good</title>
  <link rel="stylesheet" href="footerstyle.css">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@200;300;400;500;600;700;800&family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&display=swap" rel="stylesheet">
</head>
<body>
    <div class="bigb" style="display: flex; align-items: center; justify-content: space-between; padding: 0px 60px; background: linear-gradient(to bottom, #e0f2f6 82%,#dde3e6 100%); color: #777;">
        <div class="court1" style="display: flex; flex-direction: column; width: 20%; padding: 5px 20px;
        flex-wrap: wrap; align-items: center; justify-content: inline-block;">
        <img src="asset/image/logo.png" alt="" width="80" >
        <h4 style="text-decoration: underline; font-weight: 600;">Animo Ijinle</h4>
        <p style="text-align: center;">Home of books that teaches Science in Yoruba language.</p>
        <div class="social-icons">

                <a href="localhost/shopping/" class='active'><i class="icon fa fa-facebook"></i></a>
                <a href="###"><i class="icon fa fa-twitter"></i></a>
                <a href="##"><i class="icon fa fa-linkedin"></i></a>
                <a href="###"><i class="icon fa fa-rss"></i></a>
                <a href="##"><i class="icon fa fa-pinterest"></i></a>

            </div>
        </div>
        <div class="court1" style="display: flex; flex-direction: column; padding: 5px 20px; width: 20%;
        flex-wrap: wrap; align-items: center; justify-content: inline-block;"><h4 style="text-decoration: underline; font-weight: 600; padding-bottom: 20px;">Useful Links</h4>
        <a href="category.php?cid=3">Textbooks</a>
        <a href="category.php?cid=5">Sci-Fi Story</a>
        <a href="category.php?cid=4">Buy For Schools</a>
        <a href="competition.php">Competition</a>
        <a href="faqs.php">Faqs</a>
        </div>
        <div class="court1" style="display: flex; flex-direction: column; padding: 5px 20px; width: 20%;
        flex-wrap: wrap; align-items: center; justify-content: inline-block;"><h4 style="text-decoration: underline; font-weight: 600; padding-top: 35px;">Contact Us</h4>
        <div class="module-body outer-top-xs">
                    <ul class="toggle-footer" style="padding-top: 0;">
                        <li class="media">
                            <div class="pull-left">
                                <span class="icon fa-stack fa-lg">
                                <i class="fa fa-circle fa-stack-2x"></i>
                                <i class="fa fa-map-marker fa-stack-1x fa-inverse"></i>
                                </span>
                            </div>
                            <div class="media-body" style="margin-top: 0;">
                                <p>Nigeria</p>
                            </div>
                        </li>

                        <li class="media">
                            <div class="pull-left">
                                <span class="icon fa-stack fa-lg">
                                <i class="fa fa-circle fa-stack-2x"></i>
                                <i class="fa fa-mobile fa-stack-1x fa-inverse"></i>
                                </span>
                            </div>
                            <div class="media-body">
                                <p>(+234) 000000000000<br>(+234) 000000000000</p>
                            </div>
                        </li>

                        <li class="media">
                            <div class="pull-left">
                                <span class="icon fa-stack fa-lg">
                                <i class="fa fa-circle fa-stack-2x"></i>
                                <i class="fa fa-envelope fa-stack-1x fa-inverse"></i>
                                </span>
                            </div>
                            <div class="media-body">
                                <span><a href="https://urbanstalls.com/">aestylyoruba@gmail.com</a></span>
                            </div>
                        </li>

                    </ul>
                </div><!-- /.module-body -->
        </div>
        <div class="court1" style="display: flex; flex-direction: column; padding: 5px 20px; width: 20%;
        flex-wrap: wrap; align-items: center; justify-content: inline-block; list-style-type: none;"><h4 style="text-decoration: underline; font-weight: 600; padding-bottom: 20px;">Account links</h4>
        <?php if(strlen($_SESSION['login']))
            {   ?>
                    <li><a href="#"><?php echo htmlentities($_SESSION['username']);?></a></li>
                    <?php } ?>

                        <li><a href="my-account.php">My Account</a></li>
                        <li><a href="my-wishlist.php">Wishlist</a></li>
                        <li><a href="my-cart.php">My Cart</a></li>
                        <li><a href="#">Checkout</a></li>
                        <?php if(strlen($_SESSION['login'])==0)
            {   ?>
            <li><a href="login.php">Login</a></li>
            <?php }
            else{ ?>
        
                    <li><a href="logout.php">Logout</a></li>
                    <?php } ?>	
                    </ul>
                </div></div>
         </div>
        
        
  </div>
  
  <div class="copywright" style="text-align: center; background: #6a8694; color: #fff; padding: 5px;">Animo-Ijinle.com 2023</div>
</body>
</html>