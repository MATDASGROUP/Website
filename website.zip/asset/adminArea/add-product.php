<?php 
session_start();

include('connect.php');

?>



<?php include('include/admin-header.php');?>				
			<div class="span9">
					<div class="content">

						<div class="module">
							<div class="module-head">
								<h3 class="title2">Add Book</h3>
							</div>
							<div class="module-body">

									<?php if(isset($_POST['submit']))
{?>
									<div class="alert alert-success">
										<button type="button" class="close" data-dismiss="alert">×</button>
									<strong>Well done!</strong>	<?php echo htmlentities($_SESSION['msg']);?><?php echo htmlentities($_SESSION['msg']="");?>
									</div>
<?php } ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" href="styleadmin.css">
  <title>Document</title>
</head>
<body>
<div class="container mb-1 	m-auto">
  <!--<h1 class="mb-0">Add Books</h1>-->

  <form action="" method="post" enctype="multipart/form.data">
    <div class="form-outline1 mb-5 w-100 m-auto">
      <label for="book_title" class="form-label">Book title</label>
      <input type="text" name="book_title" id="book_title" class="form-control" placeholder="Enter book title" autocomplete="off" require="required">
		</div>
			<div class="form-outline1 mb-5 w-100 m-auto">
      <label for="description" class="form-label">Book description</label>
      <input type="text" name="description" id="description" class="form-control" placeholder="Enter book description" autocomplete="off" require="required">
      </div>

			<div class="form-outline1 mb-5 w-100 m-auto">
      <label for="keywords" class="form-label">Keywords</label>
      <input type="text" name="keywords" id="keywords" class="form-control" placeholder="Enter book keywords" autocomplete="off" require="required">
      </div>

			<div class="form-outline1 mb-5 w-100 m-auto">
      <label for="author" class="form-label">Author</label>
      <input type="text" name="author" id="author" class="form-control" placeholder="Enter book author" autocomplete="off" require="required">
      </div>
    </div>

		<div class="form-outline1 mb-5 w-100 m-auto">
		<label for="image1" class="form-label">Category</label>
      <select name="categories" id="" class="form-control" require="required">Category
				<option value="">Select a category</option>
				<option value="">Science</option>
				<option value="">category 2</option>
				<option value="">category 3</option>
				<option value="">category 4</option>
				<option value="">category 5</option>
			</select>

      </div>

			<div class="form-outline1 mb-10 w-100 m-auto">
      <label for="book_image1" class="form-label">image 1</label>
      <input type="file" name="book_image1" id="image1" class="form-control" require="required">
			</div>

			<div class="form-outline1 mb-10 w-100 m-auto">
      <label for="image2" image2class="form-label">image 2</label>
      <input type="file" name="image2" id="image2" class="form-control" require="required">
			</div>

			<div class="form-outline1 mb-10 w-100 m-auto">
      <label for="image3" class="form-label">image 3</label>
      <input type="file" name="image3" id="image3" class="form-control" require="required">
			</div>

			<div class="form-outline1 mb-10 w-100 m-auto">
      <label for="price_before_discount" class="form-label">Price before discount</label>
      <input type="text" name="price_before_discount" id="price_before_discount" class="form-control" placeholder="Enter price_before_discount price" autocomplete="off" require="required">
			</div>

			<div class="form-outline1 mb-10 w-100 m-auto">
      <label for="discount_price" class="form-label">Discount price</label>
      <input type="text" name="discount_price" id="discount_price" class="form-control" placeholder="Enter discounted price" autocomplete="off" require="required">
			</div>
			<div class="form-outline1 mb-10 w-70 m-auto">
      <input type="submit" name="insert_books" class="btn1" value="Upload book">
			</div>
</form>
</div>
  

</body>

</html>