<div class="footer">
		<div class="copywright">
			 

			<b class="copyright">&copy; Animo Ijinle 2023 </b> All rights reserved.
		</div>
	</div>