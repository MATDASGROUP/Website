<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Admin Dashboard</title>
  <link rel="stylesheet" href="styleAdmin.css">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
 <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@200;300;400;500;600;700;800&family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&display=swap" rel="stylesheet">
  <!--- bootstrap css link -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css">
  <!-- css link -->
 
  <style>
    .admin-img {
  width: 70px;
  object-fit: contain;
}
  </style>
</head>
<body>
  <div class="container-fluid">

    <!-- first child -->
    <div class="container">
      <div class="navbar">
          <div class="logo">
              <img src="Navtop.JPG" width="200px" alt="" id="logo">
          </div>
          <h2>Animo Ijinle</h2>
          <!--<nav>
              <ul id="menuItems">
                  <li><a href="index.html">Home</a></li>
                  <li><a href="forschool.html">Buy For School</a></li>
                  <li><a href="brainbox.html">Brainbox</a></li>
                  <li><a href="scholars.html">Scholars</a></li>
                  <li><a href="sciencefic.html">Sci-Fi Short Story</a></li>
                  <li><a href="textbook.html">Textbooks</a></li>
                  <li><a href="competition.html">Competition</a></li>
                  <li><a href="faq.html">Faqs</a></li>
              </ul>
          </nav>-->
          
      </div>
    </div>

  <!--second child -->
  <div class="title-container">
    <h3 class="title">Manage Site</h3>
  </div>

  <!-- third child -->
  <div class="row">
    <div class="col">
      <div class="badge">
        <a href="#"><img src="logo.png" class="admin-img"></a>
        <p class="text-light text-center">Admin Name</p>
      </div>
      <!--<div class="menus">
        <button><a href="add-product.php" class="menuitem">Add Product</a></button>
        <button><a href="view-productrts.php" class="menuitem">View Products</a></button>
        <button><a href="add-category.php" class="menuitem">Add Categories</a></button>
        <button><a href="view-categories.php" class="menuitem">View Categories</a></button>
        <button><a href="add-brand.php" class="menuitem">Add Brand</a></button>
        <button><a href="view-brands.php" class="menuitem">View Brands</a></button>
        <button><a href="all-orders.php" class="menuitem">All Orders</a></button>
        <button><a href="all-payment.php" class="menuitem">All Payments</a></button>
        <button><a href="logout.php" class="menuitem">Logout</a></button>
      </div>-->
    </div>
  </div>
  </div>

  <!-- forth child
  <div class="container">
    <?php  
    if(isset($_Get['add-category'])){
      include('add-category.php');
    } 

    if(isset($_Get['add-brand'])){
      include('add-brand.php');
    } 
    ?>
  </div>-->



<!--- bootstrap js link-->
<script src='https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js'></script>
</body>
</html>