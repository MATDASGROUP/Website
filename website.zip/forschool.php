<?php
session_start();
error_reporting(0);
include('<asset/adminArea/connect.php');
if(isset($_GET['action']) && $_GET['action']=="add"){
	$id=intval($_GET['id']);
	if(isset($_SESSION['cart'][$id])){
		$_SESSION['cart'][$id]['quantity']++;
	}else{
		$sql_p="SELECT * FROM products WHERE id={$id}";
		$query_p=mysqli_query($con,$sql_p);
		if(mysqli_num_rows($query_p)!=0){
			$row_p=mysqli_fetch_array($query_p);
			$_SESSION['cart'][$row_p['id']]=array("quantity" => 1, "price" => $row_p['productPrice']);
			header('location:index.php');
		}else{
			$message="Product ID is invalid";
		}
	}
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./asset/css/style.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@200;300;400;500;600;700;800&family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.2.1/css/fontawesome.min.css">
    <title>ANIMOIJINLE</title>
</head>
<body>
<?php 
            include('includes/top-header.php');
            include('includes/nav.php');
            include('includes/menubar.php');
            ?>
    
    <div class="pageTitle">
        <h3>BUY FOR SCHOOLS</h3>
        <P>An chance for you to touch lifes!</P>
    </div>


    <h2 class="title">BOOKS FOR ELEMENTARY EDUCATION</h2>
    <div class="small-container">
        <div class="row">
           <div class="col-5">
                <img src="./asset/image/pro2.jpg" alt="">
                <h4>Awa Yoruba</h4>
                <div class="rating">
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star-o"></i>
                </div>
                <p>$80.00</p>
                <a href="" class="btn1">Buy Now</a>
                <a href="" class="btn2">Add to Chat</a>
            </div>
            <div class="col-5">
                <img src="./asset/image/pro1.jpg" alt="">
                <h4>Irin-Ajo S'inu<br> Ayedimeji</h4>
                <div class="rating">
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star-o"></i>
                </div>
                <p>$30.50</p>
                <a href="" class="btn1">Buy Now</a>
                <a href="" class="btn2">Add to Chat</a>
            </div>
            
            <div class="col-5">
                <img src="./asset/image/pro3.jpg" alt="">
                <h4>Iwe Imo-Jinle <br>Ekinni</h4>
                <div class="rating">
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star-o"></i>
                </div>
                <p>$52.59</p>
                <a href="" class="btn1">Buy Now</a>
                <a href="" class="btn2">Add to Chat</a>
            </div>
            <div class="col-5">
                <img src="./asset/image/pro8.jpg" alt="">
                <h4>Bilingual of Social Studies<br>Pry. 1</h4>
                <div class="rating">
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star-o"></i>
                </div>
                <p>$19.99</p>
                <a href="" class="btn1">Buy Now</a>
                <a href="" class="btn2">Add to Chat</a>
            </div>
        
            <div class="col-5">
              <img src="./asset/image/pro9.jpg" alt="">
              <h4>Bilingual of Social Studies<br>Pry. 2</h4>
              <div class="rating">
                  <i class="fa fa-star"></i>
                  <i class="fa fa-star"></i>
                  <i class="fa fa-star"></i>
                  <i class="fa fa-star"></i>
                  <i class="fa fa-star-o"></i>
              </div>
              <p>$19.99</p>
              <a href="" class="btn1">Buy Now</a>
              <a href="" class="btn2">Add to Chat</a>
          </div>
        
          <div class="col-5">
            <img src="./asset/image/pro10.jpg" alt="">
            <h4>Bilingual of Social Studies<br>Pry. 3</h4>
            <div class="rating">
                <i class="fa fa-star"></i>
                <i class="fa fa-star"></i>
                <i class="fa fa-star"></i>
                <i class="fa fa-star"></i>
                <i class="fa fa-star-o"></i>
            </div>
            <p>$19.99</p>
            <a href="" class="btn1">Buy Now</a>
            <a href="" class="btn2">Add to Chat</a>
          </div>
            <div class="col-5">
                <img src="./asset/image/pro4.jpg" alt="">
                <h4>Beginner's Yoruba </h4>
                <div class="rating">
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star-o"></i>
                </div>
                <p>$19.99</p>
                <a href="" class="btn1">Buy Now</a>
                <a href="" class="btn2">Add to Chat</a>
            </div>
            <div class="col-5">
                <img src="./asset/image/pro5.jpg" alt="">
                <h4>Yoruba Dictionary<br>English - Yoruba</h4>
                <div class="rating">
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star-o"></i>
                </div>
                <p>$30.99</p>
                <a href="" class="btn1">Buy Now</a>
                <a href="" class="btn2">Add to Chat</a>
            </div>
            <div class="col-5">
                <img src="./asset/image/pro6.jpg" alt="">
                <h4>English - Yoruba <br>Mathematics</h4>
                <div class="rating">
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star-o"></i>
                </div>
                <p>$25.50</p>
                <a href="" class="btn1">Buy Now</a>
                <a href="" class="btn2">Add to Chat</a>
            </div>
            
            
        </div>
       </div>

       <h2 class="title">BOOKS FOR SECONDARY EDUCATION</h2>
       <div class="small-container">
        <div class="row">
          <div class="col-5">
              <img src="./asset/image/pro6.jpg" alt="">
              <h4>English - Yoruba <br>Mathematics</h4>
              <div class="rating">
                  <i class="fa fa-star"></i>
                  <i class="fa fa-star"></i>
                  <i class="fa fa-star"></i>
                  <i class="fa fa-star"></i>
                  <i class="fa fa-star-o"></i>
              </div>
              <p>$25.50</p>
              <a href="" class="btn1">Buy Now</a>
              <a href="" class="btn2">Add to Chat</a>
          </div>
          <div class="col-5">
              <img src="./asset/image/pro1.jpg" alt="">
              <h4>Irin-Ajo S'inu<br> Ayedimeji</h4>
              <div class="rating">
                  <i class="fa fa-star"></i>
                  <i class="fa fa-star"></i>
                  <i class="fa fa-star"></i>
                  <i class="fa fa-star"></i>
                  <i class="fa fa-star-o"></i>
              </div>
              <p>$30.50</p>
              <a href="" class="btn1">Buy Now</a>
              <a href="" class="btn2">Add to Chat</a>
          </div>
          <div class="col-5">
              <img src="./asset/image/pro2.jpg" alt="">
              <h4>Awa Yoruba</h4>
              <div class="rating">
                  <i class="fa fa-star"></i>
                  <i class="fa fa-star"></i>
                  <i class="fa fa-star"></i>
                  <i class="fa fa-star"></i>
                  <i class="fa fa-star-o"></i>
              </div>
              <p>$80.00</p>
              <a href="" class="btn1">Buy Now</a>
              <a href="" class="btn2">Add to Chat</a>
          </div>
          <div class="col-5">
            <img src="./asset/image/pro11.jpg" alt="">
            <h4>ABD Matimatiiki Alakobere<br>Iwe Kininni</h4>
            <div class="rating">
                <i class="fa fa-star"></i>
                <i class="fa fa-star"></i>
                <i class="fa fa-star"></i>
                <i class="fa fa-star"></i>
                <i class="fa fa-star-o"></i>
            </div>
            <p>$19.99</p>
            <a href="" class="btn1">Buy Now</a>
            <a href="" class="btn2">Add to Chat</a>
          </div>
        
          <div class="col-5">
            <img src="./asset/image/pro12.jpg" alt="">
            <h4>ABD Matimatiiki Alakobere<br>Iwe Keji</h4>
            <div class="rating">
                <i class="fa fa-star"></i>
                <i class="fa fa-star"></i>
                <i class="fa fa-star"></i>
                <i class="fa fa-star"></i>
                <i class="fa fa-star-o"></i>
            </div>
            <p>$19.99</p>
            <a href="" class="btn1">Buy Now</a>
            <a href="" class="btn2">Add to Chat</a>
          </div>
        
          <div class="col-5">
            <img src="./asset/image/pro13.jpg" alt="">
            <h4>ABD Matimatiiki Alakobere<br>Iwe Keta</h4>
            <div class="rating">
                <i class="fa fa-star"></i>
                <i class="fa fa-star"></i>
                <i class="fa fa-star"></i>
                <i class="fa fa-star"></i>
                <i class="fa fa-star-o"></i>
            </div>
            <p>$19.99</p>
            <a href="" class="btn1">Buy Now</a>
            <a href="" class="btn2">Add to Chat</a>
          </div>
            
            
        </div>
       </div>

          <h2 class="title">BOOKS FOR TERTIARY EDUCATION</h2>
          <div class="small-container">
              <div class="row">
                <div class="col-5">
                    <img src="./asset/image/pro14.png" alt="">
                    <h4>Iwe Imo-Jinle<br>Ekinni</h4>
                    <div class="rating">
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star-o"></i>
                    </div>
                    <p>$19.99</p>
                    <a href="" class="btn1">Buy Now</a>
                    <a href="" class="btn2">Add to Chat</a>
                  </div>
                
                  <div class="col-5">
                    <img src="./asset/image/pro15.png" alt="">
                    <h4>Iwe Imo-Jinle<br>Ekeji</h4>
                    <div class="rating">
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star-o"></i>
                    </div>
                    <p>$19.99</p>
                    <a href="" class="btn1">Buy Now</a>
                    <a href="" class="btn2">Add to Chat</a>
                  </div>
                
                  <div class="col-5">
                    <img src="./asset/image/pro16.png" alt="">
                    <h4>Iwe Imo-Jinle<br>Eketa</h4>
                    <div class="rating">
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star-o"></i>
                    </div>
                    <p>$19.99</p>
                    <a href="" class="btn1">Buy Now</a>
                    <a href="" class="btn2">Add to Chat</a>
                  </div>
                
                  <div class="col-5">
                    <img src="./asset/image/pro17.png" alt="">
                    <h4>Iwe Imo-Jinle<br>Ekerin</h4>
                    <div class="rating">
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star-o"></i>
                    </div>
                    <p>$19.99</p>
                    <a href="" class="btn1">Buy Now</a>
                    <a href="" class="btn2">Add to Chat</a>
                  </div>
                
                  <div class="col-5">
                    <img src="./asset/image/pro18.png" alt="">
                    <h4>Iwe Imo-Jinle<br>Ekaruun</h4>
                    <div class="rating">
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star-o"></i>
                    </div>
                    <p>$19.99</p>
                    <a href="" class="btn1">Buy Now</a>
                    <a href="" class="btn2">Add to Chat</a>
                  </div>
                
                  <div class="col-5">
                    <img src="./asset/image/pro19.png" alt="">
                    <h4>Iwe Imo-Jinle<br>Ekefa</h4>
                    <div class="rating">
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star-o"></i>
                    </div>
                    <p>$19.99</p>
                    <a href="" class="btn1">Buy Now</a>
                    <a href="" class="btn2">Add to Chat</a>
                  </div>
                  
                  
              </div>
             </div>
      

    <!---bottomMenu section-->
   <div class="categories">
    <div class="smallcontainer">
        <div class="row">
         <div class="col-5a" >
             <a href="index.html" class="bottomMenu">
                 <img src="./asset/image/AESTYL_LOGO-removebg-preview (1).png" alt="">
                 <h3>Home</h3>
             </a>
             
         </div>
             <div class="col-5a">
                 <a href="forschool.html" class="bottomMenu">
                     <img src="./asset/image/for schools.png" alt="">
                     <h3>Buy for Schools</h3>
                 </a>
                 
             </div>
             <div class="col-5a">
                 <a href="brainbox.html" class="bottomMenu">
                    <img src="./asset/image/brainbox.png" alt="">
                    <h3>Brainbox</h3> 
                 </a>
                 
             </div>
             <div class="col-5a">
                 <a href="scholars.html" class="bottomMenu">
                     <img src="./asset/image/scholars.png" alt="">
                     <h3>Scholars</h3>
                 </a>
                 
             </div>
             <div class="col-5a">
                 <a href="sciencefic.html" class="bottomMenu">
                     <img src="./asset/image/science.png" alt="">
                     <h3>Short Science Fiction</h3>
                 </a>
                 
             </div>
             <div class="col-5a">    
                 <a href="shortstory.html" class="bottomMenu">
                     <img src="./asset/image/short stories.png" alt="">
                     <h3>Short Story Books</h3>
                 </a>
             </div>
             <div class="col-5a">
                 <a href="textbook.html" class="bottomMenu">
                     <img src="./asset/image/textook.png" alt="">
                     <h3>Textbooks</h3>
                 </a>
                 
             </div>
             <div class="col-5a">
                 <a href="competition.html" class="bottomMenu">
                     <img src="./asset/image/competition.png" alt="">
                     <h3>Yoruba Competition</h3>
                 </a>
                 
             </div>
        </div>
    </div>
    </div>

     <!---footer-->
   <div class="backtotop">
    <a href=""><h4>Back to Top ˄</h4></a>
</div>
<?php include('includes/footer.php');?>

   <script>
     var menuItems = document.getElementById("menuItems");

      menuItems.style.maxHeight = "0px";

      function menutoggle(){
      if( menuItems.style.maxHeight == "0px")
       {
        menuItems.style.maxHeight = "200px";
       }
       else{
        menuItems.style.maxHeight = "0px";
       }
      }
   </script>
</body>
</html>